﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProcesamientoDatos.Clase
{

    // Clase para Procesar Datos.
    // Developer: GMEJIA
    // Fecha: 21 Agosto 2023
    public class Persona
    {
        // Atributos de la Clase
        public int id { get; set; }
        public DateTime fecha { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int KilosP { get; set; }
    }

    public class ProcesaDatos
    {

        // Atributos
        public Stopwatch TiempoProceso { get; set; }
        public List<Persona> ListaPersonas { get; set; }

        public List<Persona> ListaFiltrada { get; set; }

        public string TotalPesoLista { get; set; }
        public string TotalPesoFiltrado { get; set; }

        // Constructor
        public ProcesaDatos(string rutaArchivo)
        {
            try
            {
                CargarDesdeArchivo(rutaArchivo);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos: {ex.Message}", "Mensaje del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public double TotalPeso()
        {
            int sumaKilosP = ListaPersonas.Sum(persona => persona.KilosP);
            string formato = "N2";
            string fValor = sumaKilosP.ToString(formato);
            TotalPesoLista = fValor;
            return sumaKilosP;
        }

        private void CargarDesdeArchivo(string rutaArchivo)
        {
            // Calculo del Tiempo del Proceso
            TiempoProceso = new Stopwatch();
            TiempoProceso.Start();

            string contenido = System.IO.File.ReadAllText(rutaArchivo);
            ListaPersonas = JsonConvert.DeserializeObject<List<Persona>>(contenido);

            TiempoProceso.Stop();
        }
        public List<Persona> BusquedaConFiltro (int tipo, DateTime fechaInicio, DateTime fechaFin, string datoB)
        {

            TiempoProceso = new Stopwatch();
            TiempoProceso.Start();

            switch (tipo)
            {
                case 1: // Busqueda por Fecha
                    ListaFiltrada = ListaPersonas
                    .Where(persona => persona.fecha >= fechaInicio && persona.fecha <= fechaFin)
                    .ToList();
                    break;
                case 2: // Busqueda por ID

                    try
                    {
                     ListaFiltrada = ListaPersonas
                    .Where(persona => persona.id == int.Parse(datoB))
                    .ToList();
                        break;
                    }
                    catch (Exception ex)
                    {
                        break;
                    }                    
                case 3: // Busqueda por Nombre
                    ListaFiltrada = ListaPersonas
                    .Where(persona => persona.Nombre.Contains(datoB))
                    .ToList();
                    break;
                case 4: // Busqueda por Apellido
                    ListaFiltrada = ListaPersonas
                    .Where(persona => persona.Apellido.Contains(datoB))
                    .ToList();
                    break;
                default:
                    Console.WriteLine("Número no válido.");
                    break;
            }            

            try
            {
                int sumaKilosP = ListaFiltrada.Sum(persona => persona.KilosP);
                string formato = "N2";
                string fValor = sumaKilosP.ToString(formato);
                TotalPesoFiltrado = fValor;

                TiempoProceso.Stop();
                return ListaFiltrada;
            }
            catch {
                return ListaFiltrada;
            }
            
        }

        
    }
                        
}
