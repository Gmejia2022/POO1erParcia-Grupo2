﻿using ProcesamientoDatos.Clase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProcesamientoDatos
{
    public partial class Proceso : Form
    {

        public ProcesaDatos maestroDeDatos;

        //public MaestroCuenta CuentaEncontrada { get; private set; }
        public Proceso()
        {
            InitializeComponent();
        }

        private void Proceso_Load(object sender, EventArgs e)
        {
            // Carga datos Maestro
            maestroDeDatos = new ProcesaDatos("MOCK_DATA.json");
            //maestroCuentas.ListaCuentas();
            dataGridView1.DataSource = maestroDeDatos.ListaPersonas.ToList();
            LblTiempo.Text = ($"Tiempo: {maestroDeDatos.TiempoProceso.ElapsedMilliseconds} ms");

            LblTotal.Text = ($"Registros: {maestroDeDatos.ListaPersonas.Count}");

            Date1.Value = DateTime.Now;
            Date2.Value = DateTime.Now;

        }

        private void BtnConsulta_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = maestroDeDatos.ListaPersonas.ToList();

            double totalPeso = maestroDeDatos.TotalPeso();
            LblPeso.Text = "Total Peso: " + maestroDeDatos.TotalPesoLista.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Consulta

            dataGridView1.DataSource = maestroDeDatos.BusquedaConFiltro(1,Date1.Value, Date2.Value, "");                       

            LblTiempo.Text = ($"Tiempo Busq: {maestroDeDatos.TiempoProceso.ElapsedMilliseconds} ms");

            LblTotal.Text = ($"Registros: {maestroDeDatos.ListaFiltrada.Count}");         

            LblPeso.Text = "Total Peso: " + maestroDeDatos.TotalPesoFiltrado.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            string filtroBusqueda  = textBox1.Text;

            if (filtroBusqueda.Length > 0)
            {
                if (R1.Checked)
                {
                    dataGridView1.DataSource = maestroDeDatos.BusquedaConFiltro(2, Date1.Value, Date2.Value, filtroBusqueda != null ? filtroBusqueda : "0");
                }

                if (R2.Checked)
                {
                    dataGridView1.DataSource = maestroDeDatos.BusquedaConFiltro(3, Date1.Value, Date2.Value, filtroBusqueda != null ? filtroBusqueda : "");
                }

                if (R3.Checked)
                {
                    dataGridView1.DataSource = maestroDeDatos.BusquedaConFiltro(4, Date1.Value, Date2.Value, filtroBusqueda != null ? filtroBusqueda : "");
                }
                try
                {
                    LblTiempo.Text = ($"Tiempo Busq: {maestroDeDatos.TiempoProceso.ElapsedMilliseconds} ms");
                    LblTotal.Text = ($"Registros: {maestroDeDatos.ListaFiltrada.Count}");
                    LblPeso.Text = "Total Peso: " + maestroDeDatos.TotalPesoFiltrado.ToString();
                }
                catch (Exception ex)
                {
                    return;
                }
            }
            else
            {
                return;
            }

            
        }
    }
}
