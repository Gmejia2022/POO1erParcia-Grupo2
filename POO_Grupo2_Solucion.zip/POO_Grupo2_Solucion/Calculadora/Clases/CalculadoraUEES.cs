﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora.Clases
{
    // Clase para Operacion de una Calculadora
    // Developer: GMEJIA
    // Fecha: 21 Agosto 2023
    public class CalculadoraUEES
    {
        // Atributos
        
        public List<Calcula> CalculaHistoria;

        public Double ValorA;
        public string Operacion;

        // Constructor
        
        public CalculadoraUEES()
        {
            CalculaHistoria = new List<Calcula>();
        }

        // Metodos

        public void Proceso (double valor, string valorS, string tipo)
        {
            Calcula calculadoraP = new Calcula(valor, valorS, tipo);
            CalculaHistoria.Add(calculadoraP);
        }

        public double Suma(double a, double b)
        {
            double res = a + b;
            string ope = $"{a} + {b} = {res}";            
            return res;
        }

        public double Resta(double a, double b)
        {
            double res = a - b;
            string ope = $"{a} - {b} = {res}";
            return res;
        }

        public double Multiplica(double a, double b)
        {
            double res = a * b;
            string ope = $"{a} * {b} = {res}";
            return res;
        }

        public double Divide(double a, double b)
        {
            if (b == 0)
            {
                throw new ArgumentException("No se puede Dividir a Cero.");
            }

            double res = a / b;
            string ope = $"{a} / {b} = {res}";            
            return res;
        }

        public double Potencia(double a, double exponent)
        {
            double res = Math.Pow(a, exponent);
            string ope = $"{a} ^ {exponent} = {res}";            
            return res;
        }

        public List<Calcula> GetCalculaHistoria()
        {
            return CalculaHistoria;
        }

        public class Calcula
        {
            public double Numero { get; set; }
            public string NumeroString { get; set; }
            public string Operacion { get; set; }

            public Calcula(double numero, string numeroString, string operacion)
            {
                Numero = numero;
                Operacion = operacion;
                NumeroString = numeroString;

            }
        }

    }
}
