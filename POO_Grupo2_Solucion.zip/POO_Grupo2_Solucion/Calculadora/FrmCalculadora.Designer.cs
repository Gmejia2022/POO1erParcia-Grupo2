﻿namespace Calculadora
{
    partial class FrmCalculadora
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCalculadora));
            this.Btn1 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Btn7 = new System.Windows.Forms.Button();
            this.Btn4 = new System.Windows.Forms.Button();
            this.Btn5 = new System.Windows.Forms.Button();
            this.Btn8 = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn6 = new System.Windows.Forms.Button();
            this.Btn9 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.BtnS = new System.Windows.Forms.Button();
            this.BtnM = new System.Windows.Forms.Button();
            this.BtnR = new System.Windows.Forms.Button();
            this.BtnI = new System.Windows.Forms.Button();
            this.BtnD = new System.Windows.Forms.Button();
            this.BtnP = new System.Windows.Forms.Button();
            this.BtnC = new System.Windows.Forms.Button();
            this.BtnCE = new System.Windows.Forms.Button();
            this.TxtValor = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.LblResultado = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn1
            // 
            this.Btn1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Btn1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Btn1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.Btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn1.Location = new System.Drawing.Point(12, 403);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(65, 57);
            this.Btn1.TabIndex = 0;
            this.Btn1.Text = "1";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 478);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 57);
            this.button1.TabIndex = 1;
            this.button1.Text = "+/-";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(92, 478);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(65, 57);
            this.button2.TabIndex = 2;
            this.button2.Text = "0";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(175, 478);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(65, 57);
            this.button3.TabIndex = 3;
            this.button3.Text = ",";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Btn7
            // 
            this.Btn7.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Btn7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Btn7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.Btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn7.Location = new System.Drawing.Point(12, 255);
            this.Btn7.Name = "Btn7";
            this.Btn7.Size = new System.Drawing.Size(65, 57);
            this.Btn7.TabIndex = 4;
            this.Btn7.Text = "7";
            this.Btn7.UseVisualStyleBackColor = true;
            this.Btn7.Click += new System.EventHandler(this.Btn7_Click);
            // 
            // Btn4
            // 
            this.Btn4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Btn4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Btn4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.Btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn4.Location = new System.Drawing.Point(12, 329);
            this.Btn4.Name = "Btn4";
            this.Btn4.Size = new System.Drawing.Size(65, 57);
            this.Btn4.TabIndex = 5;
            this.Btn4.Text = "4";
            this.Btn4.UseVisualStyleBackColor = true;
            this.Btn4.Click += new System.EventHandler(this.Btn4_Click);
            // 
            // Btn5
            // 
            this.Btn5.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Btn5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Btn5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.Btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn5.Location = new System.Drawing.Point(92, 329);
            this.Btn5.Name = "Btn5";
            this.Btn5.Size = new System.Drawing.Size(65, 57);
            this.Btn5.TabIndex = 8;
            this.Btn5.Text = "5";
            this.Btn5.UseVisualStyleBackColor = true;
            this.Btn5.Click += new System.EventHandler(this.Btn5_Click);
            // 
            // Btn8
            // 
            this.Btn8.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Btn8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Btn8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.Btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn8.Location = new System.Drawing.Point(92, 255);
            this.Btn8.Name = "Btn8";
            this.Btn8.Size = new System.Drawing.Size(65, 57);
            this.Btn8.TabIndex = 7;
            this.Btn8.Text = "8";
            this.Btn8.UseVisualStyleBackColor = true;
            this.Btn8.Click += new System.EventHandler(this.Btn8_Click);
            // 
            // Btn2
            // 
            this.Btn2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Btn2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Btn2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.Btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn2.Location = new System.Drawing.Point(92, 403);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(65, 57);
            this.Btn2.TabIndex = 6;
            this.Btn2.Text = "2";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // Btn6
            // 
            this.Btn6.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Btn6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Btn6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.Btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn6.Location = new System.Drawing.Point(175, 329);
            this.Btn6.Name = "Btn6";
            this.Btn6.Size = new System.Drawing.Size(65, 57);
            this.Btn6.TabIndex = 11;
            this.Btn6.Text = "6";
            this.Btn6.UseVisualStyleBackColor = true;
            this.Btn6.Click += new System.EventHandler(this.Btn6_Click);
            // 
            // Btn9
            // 
            this.Btn9.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Btn9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Btn9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.Btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn9.Location = new System.Drawing.Point(175, 255);
            this.Btn9.Name = "Btn9";
            this.Btn9.Size = new System.Drawing.Size(65, 57);
            this.Btn9.TabIndex = 10;
            this.Btn9.Text = "9";
            this.Btn9.UseVisualStyleBackColor = true;
            this.Btn9.Click += new System.EventHandler(this.Btn9_Click);
            // 
            // Btn3
            // 
            this.Btn3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Btn3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Btn3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.Btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn3.Location = new System.Drawing.Point(175, 403);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(65, 57);
            this.Btn3.TabIndex = 9;
            this.Btn3.Text = "3";
            this.Btn3.UseVisualStyleBackColor = true;
            this.Btn3.Click += new System.EventHandler(this.Btn3_Click);
            // 
            // BtnS
            // 
            this.BtnS.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnS.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnS.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
            this.BtnS.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Linen;
            this.BtnS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnS.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnS.Location = new System.Drawing.Point(258, 329);
            this.BtnS.Name = "BtnS";
            this.BtnS.Size = new System.Drawing.Size(65, 57);
            this.BtnS.TabIndex = 15;
            this.BtnS.Text = "+";
            this.BtnS.UseVisualStyleBackColor = false;
            this.BtnS.Click += new System.EventHandler(this.BtnS_Click);
            // 
            // BtnM
            // 
            this.BtnM.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnM.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnM.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
            this.BtnM.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Linen;
            this.BtnM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnM.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnM.Location = new System.Drawing.Point(258, 255);
            this.BtnM.Name = "BtnM";
            this.BtnM.Size = new System.Drawing.Size(65, 57);
            this.BtnM.TabIndex = 14;
            this.BtnM.Text = "x";
            this.BtnM.UseVisualStyleBackColor = false;
            this.BtnM.Click += new System.EventHandler(this.BtnM_Click);
            // 
            // BtnR
            // 
            this.BtnR.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnR.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
            this.BtnR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Linen;
            this.BtnR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnR.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnR.Location = new System.Drawing.Point(258, 403);
            this.BtnR.Name = "BtnR";
            this.BtnR.Size = new System.Drawing.Size(65, 57);
            this.BtnR.TabIndex = 13;
            this.BtnR.Text = "-";
            this.BtnR.UseVisualStyleBackColor = false;
            this.BtnR.Click += new System.EventHandler(this.BtnR_Click);
            // 
            // BtnI
            // 
            this.BtnI.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnI.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnI.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
            this.BtnI.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Linen;
            this.BtnI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnI.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnI.Location = new System.Drawing.Point(258, 478);
            this.BtnI.Name = "BtnI";
            this.BtnI.Size = new System.Drawing.Size(65, 57);
            this.BtnI.TabIndex = 12;
            this.BtnI.Text = "=";
            this.BtnI.UseVisualStyleBackColor = false;
            this.BtnI.Click += new System.EventHandler(this.BtnI_Click);
            // 
            // BtnD
            // 
            this.BtnD.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnD.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnD.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
            this.BtnD.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Linen;
            this.BtnD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnD.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnD.Location = new System.Drawing.Point(258, 176);
            this.BtnD.Name = "BtnD";
            this.BtnD.Size = new System.Drawing.Size(65, 57);
            this.BtnD.TabIndex = 16;
            this.BtnD.Text = "÷";
            this.BtnD.UseVisualStyleBackColor = false;
            this.BtnD.Click += new System.EventHandler(this.BtnD_Click);
            // 
            // BtnP
            // 
            this.BtnP.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnP.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnP.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
            this.BtnP.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Linen;
            this.BtnP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnP.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnP.Location = new System.Drawing.Point(175, 176);
            this.BtnP.Name = "BtnP";
            this.BtnP.Size = new System.Drawing.Size(65, 57);
            this.BtnP.TabIndex = 17;
            this.BtnP.Text = "^";
            this.BtnP.UseVisualStyleBackColor = false;
            this.BtnP.Click += new System.EventHandler(this.BtnP_Click);
            // 
            // BtnC
            // 
            this.BtnC.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnC.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnC.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
            this.BtnC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Linen;
            this.BtnC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnC.Location = new System.Drawing.Point(12, 176);
            this.BtnC.Name = "BtnC";
            this.BtnC.Size = new System.Drawing.Size(65, 57);
            this.BtnC.TabIndex = 18;
            this.BtnC.Text = "C";
            this.BtnC.UseVisualStyleBackColor = false;
            this.BtnC.Click += new System.EventHandler(this.BtnC_Click);
            // 
            // BtnCE
            // 
            this.BtnCE.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnCE.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnCE.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
            this.BtnCE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Linen;
            this.BtnCE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCE.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCE.Location = new System.Drawing.Point(92, 176);
            this.BtnCE.Name = "BtnCE";
            this.BtnCE.Size = new System.Drawing.Size(65, 57);
            this.BtnCE.TabIndex = 19;
            this.BtnCE.Text = "<<";
            this.BtnCE.UseVisualStyleBackColor = false;
            this.BtnCE.Click += new System.EventHandler(this.BtnCE_Click);
            // 
            // TxtValor
            // 
            this.TxtValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtValor.Location = new System.Drawing.Point(12, 120);
            this.TxtValor.Name = "TxtValor";
            this.TxtValor.ReadOnly = true;
            this.TxtValor.Size = new System.Drawing.Size(311, 38);
            this.TxtValor.TabIndex = 20;
            this.TxtValor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 31;
            this.listBox1.Location = new System.Drawing.Point(338, 120);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(318, 376);
            this.listBox1.TabIndex = 21;
            // 
            // LblResultado
            // 
            this.LblResultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblResultado.ForeColor = System.Drawing.Color.Blue;
            this.LblResultado.Location = new System.Drawing.Point(335, 504);
            this.LblResultado.Name = "LblResultado";
            this.LblResultado.Size = new System.Drawing.Size(318, 31);
            this.LblResultado.TabIndex = 22;
            this.LblResultado.Text = "Resultado:";
            this.LblResultado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Location = new System.Drawing.Point(215, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(401, 31);
            this.label3.TabIndex = 26;
            this.label3.Text = "Lenguajes de Programación";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(215, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(354, 31);
            this.label2.TabIndex = 25;
            this.label2.Text = "Calculadora Básica";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(215, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 31);
            this.label1.TabIndex = 24;
            this.label1.Text = "Grupo 2:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(197, 102);
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            // 
            // FrmCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(668, 546);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.LblResultado);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.TxtValor);
            this.Controls.Add(this.BtnCE);
            this.Controls.Add(this.BtnC);
            this.Controls.Add(this.BtnP);
            this.Controls.Add(this.BtnD);
            this.Controls.Add(this.BtnS);
            this.Controls.Add(this.BtnM);
            this.Controls.Add(this.BtnR);
            this.Controls.Add(this.BtnI);
            this.Controls.Add(this.Btn6);
            this.Controls.Add(this.Btn9);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn5);
            this.Controls.Add(this.Btn8);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.Btn4);
            this.Controls.Add(this.Btn7);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Btn1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmCalculadora";
            this.Text = "Calculadora UEES - Grupo 2 / Lenguajes de Programacion";
            this.Load += new System.EventHandler(this.FrmCalculadora_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button Btn7;
        private System.Windows.Forms.Button Btn4;
        private System.Windows.Forms.Button Btn5;
        private System.Windows.Forms.Button Btn8;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn6;
        private System.Windows.Forms.Button Btn9;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Button BtnS;
        private System.Windows.Forms.Button BtnM;
        private System.Windows.Forms.Button BtnR;
        private System.Windows.Forms.Button BtnI;
        private System.Windows.Forms.Button BtnD;
        private System.Windows.Forms.Button BtnP;
        private System.Windows.Forms.Button BtnC;
        private System.Windows.Forms.Button BtnCE;
        private System.Windows.Forms.TextBox TxtValor;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label LblResultado;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

