﻿using Calculadora.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Header;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace Calculadora
{

    // Calculadora Funcional
    // Developer: GMEJIA
    // Fecha: 21 Agosto 2023
    public partial class FrmCalculadora : Form
    {

        private string ValorA;
        private double ValorADouble;
        private double valorCalculado;

        private CalculadoraUEES calculadoraObj;

        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            numero("1");
        }

        private void numero (string valor)
        {
            string ValorB = valor;            

            string ValorC = $"{ValorA}{ValorB}";
            int cantDecimales = CuentaDecimales(ValorC);
          
            if (double.TryParse(ValorC, out double dValor))
            {

                // El número NO tiene decimales
                //string formato = $"N{cantDecimales}";
                string formato = "N0";
                string fValor = dValor.ToString(formato);
                    ValorADouble = dValor;
                    ValorA = fValor;
                    TxtValor.Text = ValorA;               
            }
            else
            {
                
            }                    
        }

        private void BtnCE_Click(object sender, EventArgs e)
        {
            try
            {
                string OString = ValorA;
                string ValorC = OString.Remove(OString.Length - 1);

                ValorA = ValorC;
                TxtValor.Text = ValorA;
            }
            catch (Exception ex)
            {
                
            }           
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            numero("2");
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            numero("3");
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            numero("4");
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            numero("5");
        }

        private void Btn6_Click(object sender, EventArgs e)
        {
            numero("6");
        }

        private void Btn7_Click(object sender, EventArgs e)
        {
            numero("7");
        }

        private void Btn8_Click(object sender, EventArgs e)
        {
            numero("8");
        }

        private void Btn9_Click(object sender, EventArgs e)
        {
            numero("9");
        }

        private void BtnC_Click(object sender, EventArgs e)
        {
            ValorA = "";
            TxtValor.Text = ValorA;
            listBox1.Items.Clear();
            LblResultado.Text = "";
            calculadoraObj.CalculaHistoria.Clear();
            valorCalculado = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            numero("0");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //numero(",");
        }

        static int CuentaDecimales(string stringValue)
        {
            int decimalIndex = stringValue.IndexOf('.');

            if (decimalIndex >= 0)
            {
                return stringValue.Length - decimalIndex - 1;
            }

            return 0; // No hay decimales
        }

        private void BtnR_Click(object sender, EventArgs e)
        {
            presentaLista("-");
        }

        private void calculaLista ()
        {
            valorCalculado = 0;

            int totalItems = calculadoraObj.CalculaHistoria.Count;

            if (totalItems == 0)
            {
                return;
            }
            // Recorre la Lista para Procesar los Valores

            for (int i = 1; i <= totalItems; i++)
            {
                double valorActual = calculadoraObj.CalculaHistoria[i - 1].Numero;
                string operacion = calculadoraObj.CalculaHistoria[i - 1].Operacion;
                
                switch (operacion)
                {
                    case "+":
                        valorCalculado += valorActual;
                        try
                        {                          
                                valorCalculado += calculadoraObj.CalculaHistoria[i].Numero;                            
                        }
                        catch
                        {
                            break;
                        }
                        break;
                    case "-":
                        if (valorCalculado == 0)
                        {
                            valorCalculado = valorActual;
                        }
                            try
                            {                                
                                    valorCalculado -= calculadoraObj.CalculaHistoria[i].Numero;                             
                            }
                            catch
                            {
                                break;
                            }
                            break;
                    case "x":
                        if (valorCalculado == 0)
                        {
                            valorCalculado = valorActual;
                        }
                        try
                        {
                            valorCalculado *= calculadoraObj.CalculaHistoria[i].Numero;
                        }
                        catch
                        {
                            break;
                        }
                        break;
                    case "/":
                        if (valorCalculado == 0)
                        {
                            valorCalculado = valorActual;
                        }
                        try
                        {
                            valorCalculado /= calculadoraObj.CalculaHistoria[i].Numero;
                        }
                        catch
                        {
                            break;
                        }
                        break;
                    case "P":
                        if (valorCalculado == 0)
                        {
                            valorCalculado = valorActual;
                        }
                        try
                        {
                            valorCalculado = Math.Pow(valorCalculado, calculadoraObj.CalculaHistoria[i].Numero);
                            
                        }
                        catch
                        {
                            break;
                        }
                        break;
                }
            }

            string formato = "N0";
            string fValor = valorCalculado.ToString(formato);
            LblResultado.Text = "Resultado: " + fValor;

        }
        private void presentaLista(string proceso)
        {
           
            if (ValorADouble == 0)
            {
                return;
            }

            calculadoraObj.Proceso(ValorADouble, ValorA, proceso);
            //listBox1.DataSource = calculadoraObj.GetCalculaHistoria();

            int totalItems = calculadoraObj.CalculaHistoria.Count;

            listBox1.Items.Clear();

            for (int i = 1; i <= totalItems; i++)
            {
                listBox1.Items.Add(calculadoraObj.CalculaHistoria[i - 1].NumeroString);
                listBox1.Items.Add(calculadoraObj.CalculaHistoria[i - 1].Operacion);
            }
            listBox1.RightToLeft = RightToLeft.Yes;
            ValorA = "";
            ValorADouble = 0;
            TxtValor.Text = "";
    }
        private void FrmCalculadora_Load(object sender, EventArgs e)
        {
            calculadoraObj = new CalculadoraUEES();

                }

        private void BtnS_Click(object sender, EventArgs e)
        {
            presentaLista("+");
        }

        private void BtnM_Click(object sender, EventArgs e)
        {
            presentaLista("x");
        }

        private void BtnD_Click(object sender, EventArgs e)
        {
            presentaLista("/");
        }

        private void BtnP_Click(object sender, EventArgs e)
        {
            presentaLista("P");
        }

        private void BtnI_Click(object sender, EventArgs e)
        {
            presentaLista("=");

            calculaLista();
        }
    }
}
